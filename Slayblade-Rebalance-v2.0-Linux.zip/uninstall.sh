#!/usr/bin/env bash
#
# Restores Slayblade.exe and language.csv from the .orig backups made at install
# time, then removes the backups. Puts you back to a completely clean install.

set -u
cd "$(dirname "$(readlink -f "$0")")" || exit 1

PY=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
    echo "! Python 3 was not found. Install it and run this again."
    exit 1
fi

"$PY" ./slaymod_patcher.py --revert "$@"
status=$?

echo
if [ -t 0 ]; then
    printf 'Press Enter to close. '
    read -r _
fi
exit $status
