#!/usr/bin/env bash
#
# Slayblade - Rebalance Mod Pack
# Installer for Linux, SteamOS and the Steam Deck.
#
# The game is a Windows build running under Proton, so the files on disk are the
# same ones the Windows installer patches. No root, no sudo: everything lives in
# your own home directory.

set -u
cd "$(dirname "$(readlink -f "$0")")" || exit 1

PY=""
for c in python3 python3.11 python3.10 python3.9 python; do
    if command -v "$c" >/dev/null 2>&1; then
        if "$c" -c 'import sys; raise SystemExit(0 if sys.version_info[0] == 3 else 1)' 2>/dev/null; then
            PY="$c"; break
        fi
    fi
done

if [ -z "$PY" ]; then
    cat <<'MSG'
! Python 3 was not found on this system.

  SteamOS and the Steam Deck ship with it, as do almost all desktop distributions,
  so this is unusual. Install it with your package manager and run this again:

      Debian / Ubuntu / Mint     sudo apt install python3
      Fedora                     sudo dnf install python3
      Arch / Manjaro             sudo pacman -S python
MSG
    exit 1
fi

"$PY" ./slaymod_patcher.py "$@"
status=$?

echo
if [ -t 0 ]; then
    printf 'Press Enter to close. '
    read -r _
fi
exit $status
