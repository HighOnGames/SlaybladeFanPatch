@echo off
REM Reports which patches are currently applied. Changes nothing.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "slaymod_patcher.ps1" -Verify
echo.
pause
