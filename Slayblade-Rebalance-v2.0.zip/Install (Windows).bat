@echo off
REM Slayblade Rebalance Mod Pack - installer
REM No Python required. Uses the PowerShell that ships with Windows.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "slaymod_patcher.ps1" %*
echo.
pause
